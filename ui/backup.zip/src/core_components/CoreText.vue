<template>
  <!-- <teleport :to="`#g${to}-${col}`" :disabled="to == null" v-if="isMounted"> -->
    <div
      class="CoreText component"
      :data-streamsync-id="componentId"
      v-show="!isPlaceholder"
    >
      <slot>{{ text }}</slot>
    </div>
  <!-- </teleport> -->
</template>

<script>
export default {
  inject: ["streamsync"],
  props: {
    componentId: String
  },
  mounted: function () {
    this.streamsync.addEventListeners(this.componentId, this.$el);
  },
  computed: {
    text: function () {
      let content = this.streamsync.getContentValue(this.componentId, "text");
      return content;
    },
    isPlaceholder: function () {
      let show = this.streamsync.components[this.componentId].placeholder;
      return show;
    },
  },
};
</script>

<style>
/* .CoreText {
  font-size: 0.8rem;
  white-space: pre-wrap;
} */
</style>
